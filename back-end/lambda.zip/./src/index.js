"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const app_1 = __importDefault(require("./app"));
const getPoke_1 = __importDefault(require("./endPoints/getPoke"));
const createPoke_1 = __importDefault(require("./endPoints/createPoke"));
const deletePoke_1 = __importDefault(require("./endPoints/deletePoke"));
const getDetalhes_1 = __importDefault(require("./endPoints/getDetalhes"));
const editPoke_1 = __importDefault(require("./endPoints/editPoke"));
const lbn_lambda_express_1 = require("lbn-lambda-express");
app_1.default.get('/pokeRedFox/get', getPoke_1.default);
app_1.default.get('/pokeRedFox/getDetalhes/:id', getDetalhes_1.default);
app_1.default.post('/pokeRedFox/post', createPoke_1.default);
app_1.default.delete('/pokeRedFox/delete', deletePoke_1.default);
app_1.default.post('/pokeRedFox/editPoke/:id', editPoke_1.default);
exports.handler = lbn_lambda_express_1.createLambdaHandler(app_1.default);
